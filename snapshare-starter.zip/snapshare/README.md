# SnapShare
A responsive photo-album website for GitHub Pages with Supabase database, authentication and photo storage.

## Setup
1. In Supabase, create a project and open SQL Editor.
2. Run all of `supabase-setup.sql`.
3. In Supabase Authentication → Users, create your own admin user. For a single-admin website, disable public sign-ups in Authentication settings.
4. In Project Settings → API, copy the Project URL and the public anon/publishable key. Never expose a service-role key.
5. Commit `index.html`, `supabase-setup.sql`, and `.nojekyll` to the root of your GitHub repository.
6. In GitHub repository Settings → Pages, choose Deploy from a branch, select `main` and `/(root)`, and Save.
7. Open your published Pages site, expand “Connect Supabase”, enter the project URL and public key, and connect.
8. Log in, create an album, upload photos, then share the album link.

## Privacy and limits
The photo storage bucket is public by design so people can view and download photos without accounts. Anyone with a photo URL can forward it. Do not upload sensitive/private images. ZIP creation happens in each visitor's browser; very large albums may need to be downloaded in smaller selections, especially on phones.
