-- SnapShare exact-duplicate detection migration.
-- Additive and safe to rerun. No tables or rows are dropped or recreated.
alter table public.photos add column if not exists content_hash text;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.photos'::regclass
      and conname = 'photos_content_hash_format_check'
  ) then
    alter table public.photos
      add constraint photos_content_hash_format_check
      check (content_hash is null or content_hash ~ '^[0-9a-f]{64}$') not valid;
  end if;
end $$;

-- Deliberately non-unique so historical duplicates do not break migration.
create index if not exists photos_content_hash_idx
  on public.photos (content_hash) where content_hash is not null;

comment on column public.photos.content_hash is
  'SHA-256 hex digest of original file bytes; NULL for legacy photos until backfilled.';
