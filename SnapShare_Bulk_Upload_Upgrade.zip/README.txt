SNAPSHARE — BULK UPLOAD AND EXACT DUPLICATE DETECTION
=====================================================

PACKAGE FILES
- admin.html: bulk upload, progress/counts, exact duplicate detection, failed-file retry, existing album creation and management.
- index.html: compatible public gallery implementation preserving the existing Supabase project, ?album=<album-id> shared-link format, album listing, photo viewer, single downloads, selection, sharing and ZIP downloads.
- migration-add-content-hash.sql: additive migration for a nullable SHA-256 hash and lookup index.
- README.txt: installation and limitations.

IMPORTANT: The original repository's index.html was inspected for its schema and behavior. This package's index.html is a feature-compatible version, not a byte-for-byte copy. If your current public gallery has custom changes you want to preserve exactly, keep your repository's current index.html instead of replacing it; the bulk uploader does not require a public-gallery code change.

INSTALL
1. Unzip this package.
2. In your GitHub repository, replace admin.html. Keep the existing index.html if you want to preserve its exact current presentation/custom changes.
3. In Supabase Dashboard > SQL Editor, review and run migration-add-content-hash.sql. It adds a column and index only; it does not drop tables, reset the database, or delete records.
4. Commit/push the changed file(s) to the branch configured for GitHub Pages and wait for deployment.
5. Sign in to the existing admin page. Choose an existing album, select images and upload. Uploading photos never creates an album. Choose the same album for later batches to keep its ID and public link unchanged.

IPHONE / BATCHES
Start with 20–50 photos per batch. Larger selections depend on the phone, browser memory, network and storage. Check the selected count after returning from the picker. If it is zero, the picker returned no files; reopen it and try again.

DUPLICATE DETECTION
SHA-256 detects byte-for-byte identical original files. Resized, edited, recompressed or converted copies can have different hashes. Existing photo rows with NULL content_hash cannot be hash-compared until backfilled; the migration does not automatically identify all historical duplicates. The hash index is non-unique to avoid failing when legacy duplicate records exist. Two administrators uploading identical files simultaneously can race; strict global enforcement needs a server-side transaction/RPC or Edge Function.

SECURITY / TESTING
The existing Supabase publishable key is intended for browser use; no service-role key is included. RLS and Storage policies remain responsible for authorization. Verify current policies restrict uploads/deletes to intended administrators; a login screen alone is not security. This package was not tested against live Supabase auth/storage. The migration is based on the repository's current supabase-setup.sql; verify actual remote schema and policies before deploying. Old rows are preserved and remain unhashed until backfilled.

The public gallery ZIP is generated in the browser. Very large albums may exceed mobile browser memory; download smaller selections when needed. Per-file limit remains 25 MiB.
